import os

print("开始安装, 预计安装时间30秒")
os.system("pip install /root/Chinese_license_plate_detection_recognition/dependency/*.whl")
print("安装完成,按Home建退出.")